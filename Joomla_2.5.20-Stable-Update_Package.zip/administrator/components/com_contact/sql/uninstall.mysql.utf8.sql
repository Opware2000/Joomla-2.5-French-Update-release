DROP TABLE IF EXISTS `#__contact_details`;

